<?php
	class General
	{
		public static function site_title()
		{
			echo "HIST Chat Application";
		}
		
		public static function site_header()
		{
			?>
				<h1 align="center" style="background-color: teal; padding: 20px; color: white; border-radius: 20px">HIST Group Chat Application</h1>
				<hr />
			<?php
		}
	}
?>